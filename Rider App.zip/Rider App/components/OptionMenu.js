import {View, Text, StyleSheet} from 'react-native';

const OptionMenu = props => {
  return (
    <View style={styles.container}>
      <Text>{'Option 1'}</Text>
    </View>
  );
};

export default OptionMenu;

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    right: 0,
  },
});
