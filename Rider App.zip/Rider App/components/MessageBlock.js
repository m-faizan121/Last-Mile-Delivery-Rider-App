import {View, Text, StyleSheet} from 'react-native';

const MessageBlock = props => {
  return (
    <View style={styles.container}>
      <Text style={props.style}>{props.message}</Text>
    </View>
  );
};

export default MessageBlock;

const styles = StyleSheet.create({
  container: {
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
    textAlign: 'center',
    alignContent: 'center',
    backgroundColor: '#009387',
    elevation: 5,
  },
});
