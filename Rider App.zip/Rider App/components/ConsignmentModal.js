import React from 'react';
import Modal from 'react-native-modal';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import {Divider} from 'react-native-paper';
import {COLORS} from '../resources/resources';

const ConsignmentModal = props => {
  const data = props.data;
  return (
    <Modal isVisible={true} on>
      <View style={styles.modal}>
        <Text style={styles.header}>Consignment Details</Text>
        <Divider
          style={{
            color: COLORS.greenColor,
            borderBottomWidth: 0.5,
            marginTop: 10,
          }}></Divider>

        <View style={styles.content}>
          <View style={styles.informationRow}>
            <View>
              <Text style={styles.heading}>Consignment #</Text>
            </View>
            <View>
              <Text style={{...styles.heading2, marginLeft: '12%'}}>
                {' '}
                {data.consignment_no || 'CS-12345'}
              </Text>
            </View>
          </View>
          <View style={styles.informationRow}>
            <Text style={styles.heading}>Name</Text>
            <Text style={{...styles.heading2, marginLeft: '26%'}}>
              {data.name || 'Muhammad Faizan'}
            </Text>
          </View>
          <View style={styles.informationRow}>
            <Text style={styles.heading}>Phone #</Text>
            <Text style={{...styles.heading2, marginLeft: '21%'}}>
              {data.contact || '+92 304 5067949'}
            </Text>
          </View>
          <View style={styles.informationRow}>
            <Text style={styles.heading}>Address</Text>
            <Text style={{...styles.heading2, marginLeft: '21%'}}>
              {data.address || 'Ameer Hamza Colony St # 5'}
            </Text>
          </View>
          <View style={styles.informationRow}>
            <Text style={styles.heading}>Details</Text>
            <Text style={{...styles.heading2, marginLeft: '24%'}}>
              {data.description || 'Leather Jacket, Shoes and Watch'}
            </Text>
          </View>
          <View style={styles.informationRow}>
            <Text style={styles.heading}>Status</Text>
            <Text
              style={{
                ...styles.heading2,
                marginLeft: '25%',
                color: data.status ? 'green' : 'red',
              }}>
              <Text style={{fontWeight: '500'}}>
                {data.status ? 'Delivered' : 'Pending'}
              </Text>
            </Text>
          </View>
          {data.status && (
            <View style={styles.informationRow}>
              <Text style={styles.heading}>Delivered At</Text>
              <Text style={{...styles.heading2, marginLeft: '14%'}}>
                {data.delivery_date || '2022-8-4, 2:42 pm'}
              </Text>
            </View>
          )}
        </View>

        <TouchableOpacity
          activeOpacity={0.8}
          style={[styles.button, styles.buttonClose]}
          onPress={props.onModalClose}>
          <Text style={{color: 'white', fontWeight: '500'}}>Close</Text>
        </TouchableOpacity>
      </View>
    </Modal>
  );
};

export default ConsignmentModal;

const styles = StyleSheet.create({
  modal: {
    backgroundColor: 'white',
    paddingVertical: 15,
    height: 'auto',
    width: '95%',
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#fff',
    marginTop: 0,
    marginLeft: 10,
  },
  header: {
    fontSize: 18,
    fontWeight: '500',
    textAlign: 'center',
    color: COLORS.greenColor,
  },
  content: {
    paddingHorizontal: 20,
    paddingTop: 10,
  },
  button: {
    borderRadius: 15,
    padding: 10,
    marginLeft: 80,
    marginRight: 80,
    elevation: 2,
    alignItems: 'center',
    marginTop: 30,
  },
  buttonOpen: {
    backgroundColor: '#009387',
  },
  buttonClose: {
    backgroundColor: '#009387',
    padding: 10,
  },
  heading: {
    fontWeight: '500',
    color: 'black',
    fontSize: 12,
    marginLeft: 5,
  },
  heading2: {
    fontWeight: 'normal',
    color: 'black',
    fontSize: 12,
    marginRight: 50,
  },
  informationRow: {
    display: 'flex',

    flexDirection: 'row',
    marginTop: 10,
  },
});
