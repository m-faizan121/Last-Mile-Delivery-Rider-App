import {useState} from 'react';
import {View, StyleSheet, Text} from 'react-native';
import {TouchableOpacity} from 'react-native-gesture-handler';
import {ActivityIndicator, Checkbox} from 'react-native-paper';
import {COLORS} from '../../resources/resources';

const CustomerListItem = props => {
  const [updating, setUpdating] = useState({
    loading: false,
    modal: false,
  });

  const checkBoxHandler = () => {
    setUpdating({
      loading: true,
      modal: false,
    });
    setTimeout(() => {
      props.checkBoxEvent(props);
      setUpdating({
        loading: false,
        modal: true,
      });
    }, 1500);
  };

  return (
    <TouchableOpacity
      activeOpacity={0.8}
      style={styles.container}
      onPress={() => {
        if (!updating.loading) props.onClick();
      }}>
      <Text style={styles.name}>{props.consignment_no}</Text>
      <Text style={styles.address}>{props.address}</Text>
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          marginTop: 16,
        }}>
        {updating.loading && (
          <ActivityIndicator
            color="#31FF39"
            size={'small'}
            style={styles.wait}
          />
        )}
        {!updating.loading && (
          <Text
            style={{
              ...styles.status,
              color: '#D9E2E1',
            }}>
            {props.status ? 'Delivered' : 'Pending'}
          </Text>
        )}
        <Checkbox
          uncheckedColor="black"
          color="black"
          onPress={checkBoxHandler}
          status={props.status ? 'checked' : 'unchecked'}
        />
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  btn: {
    padding: 10,
    backgroundColor: '#06514E',
    borderRadius: 5,
    width: 110,
    alignItems: 'center',
    elevation: 5,
  },
  container: {
    height: 'auto',
    padding: 15,
    backgroundColor: COLORS.greenColor,
    borderRadius: 5,
    marginTop: 10,
    elevation: 3,
  },
  id: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  name: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#31FF39',
  },
  address: {
    marginTop: 5,
    fontSize: 14,
    fontWeight: 'bold',
    color: '#fff',
  },
  status: {
    marginTop: 5,
    fontSize: 15,
    fontWeight: 'bold',
    elevation: 10,
  },
  wait: {
    color: 'white',
    marginLeft: 10,
  },
});

export default CustomerListItem;
