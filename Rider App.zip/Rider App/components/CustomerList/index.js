import {View, StyleSheet, ScrollView} from 'react-native';
import {SearchBar} from 'react-native-elements';
import {SafeAreaView} from 'react-native-safe-area-context';
import React, {useState} from 'react';
import CustomerListItem from './CustomerListItem';
import MessageBlock from '../MessageBlock';

const CustomerList = props => {
  const [query, setQuery] = useState('');

  const handleSearch = value => {
    setQuery(value);
  };

  const handleItemPress = item => {
    props.navigation.push('CustomersScreen', {
      sheet: item,
    });
  };

  React.useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      setQuery('');
    });

    // Return the function to unsubscribe from the event so it gets removed on unmount
    return unsubscribe;
  }, []);

  return (
    <SafeAreaView>
      <View style={styles.container}>
        <SearchBar
          placeholder="Search Customer"
          value={query}
          inputStyle={{backgroundColor: 'white'}}
          containerStyle={{
            backgroundColor: 'white',
            borderWidth: 1,
            borderRadius: 5,
            elevation: 3,
            marginTop: 3,
          }}
          inputContainerStyle={{backgroundColor: 'white', height: 25}}
          onChangeText={text => handleSearch(text)}
          leftIconContainerStyle={{marginBottom: 8, marginRight: -7}}
          autoCorrect={false}
        />

        {props.options.length === 0 ? (
          <View style={{marginTop: 20}}>
            <MessageBlock
              message={'No Items Found'}
              style={{fontSize: 16, color: '#000', fontWeight: '500'}}
            />
          </View>
        ) : (
          <ScrollView
            contentContainerStyle={{flexGrow: 1}}
            showsVerticalScrollIndicator={false}
            style={styles.items}>
            {props.options.map((item, idx) => {
              if (item.name.includes(query)) {
                return (
                  <CustomerListItem
                    key={idx}
                    name={item.name}
                    address={item.address}
                    status={item.status}
                  />
                );
              }
            })}
          </ScrollView>
        )}
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 10,
  },
  searchBar: {
    elevation: 0,
    borderColor: 'black',
    borderRadius: 2,
    marginTop: 5,
    backgroundColor: 'white',
  },
  items: {
    marginTop: 15,
    height: '88%',
  },
});

export default CustomerList;
