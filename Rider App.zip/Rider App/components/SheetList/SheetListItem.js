import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';

const SheetListItem = props => {
  const date = new Date(props.item.sheetContent.date);

  return (
    <TouchableOpacity
      style={styles.container}
      activeOpacity={0.8}
      onPress={() => {
        props.handleItemPress(props.item);
      }}>
      <View>
        <Text style={styles.name}>{props.item.sheetContent.sheet_no}</Text>
        <Text style={styles.address}>
          {date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
          })}
        </Text>
        <Text
          style={{
            ...styles.address,
            marginTop: 10,
            color: '#D9E2E1',
            fontWeight: '700',
          }}>
          <Text style={{color: '#D9E2E1'}}>
            {props.item.sheetContent.sheet
              ? Object.keys(props.item.sheetContent.sheet).length
              : 0}{' '}
          </Text>
          <Text>Consignments</Text>
        </Text>
      </View>
      <View>
        <MaterialIcons
          style={{marginTop: 30, marginLeft: 50}}
          name="navigate-next"
          color="#fff"
          size={25}
        />
      </View>
    </TouchableOpacity>
  );
};

export default SheetListItem;

const styles = StyleSheet.create({
  btn: {
    padding: 10,
    backgroundColor: '#06514E',
    borderRadius: 10,
    width: 110,
    alignItems: 'center',
    elevation: 5,
  },
  container: {
    height: 'auto',
    padding: 15,
    backgroundColor: '#009387',
    borderRadius: 5,
    marginTop: 10,
    elevation: 3,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  id: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  name: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#31FF39',
  },
  address: {
    marginTop: 5,
    fontSize: 14,
    fontWeight: 'bold',
    color: '#fff',
  },
  status: {
    marginTop: 5,
    fontSize: 15,
    fontWeight: 'bold',
    color: '#31FF39',
    elevation: 10,
  },
  wait: {
    color: 'white',
    marginLeft: 10,
  },
});
