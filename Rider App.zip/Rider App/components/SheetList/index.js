import {View, StyleSheet, ScrollView} from 'react-native';
import {SearchBar} from 'react-native-elements';
import SheetListItem from '../SheetList/SheetListItem';
import {SafeAreaView} from 'react-native-safe-area-context';
import {useState} from 'react';

const SheetList = props => {
  const [query, setQuery] = useState('');

  const handleSearch = value => {
    setQuery(value);
  };

  const handleItemPress = item => {
    props.navigation.push('CustomersScreen', {
      sheet: item,
    });
  };

  return (
    <SafeAreaView>
      <View style={styles.container}>
        <SearchBar
          placeholder="Search Delivery Sheet"
          value={query}
          inputStyle={{backgroundColor: 'white'}}
          containerStyle={{
            backgroundColor: 'white',
            borderWidth: 1,
            borderRadius: 5,
            elevation: 3,
            marginTop: 3,
            borderColor: 'white',
            borderBottomColor: 'white',
            borderTopColor: 'white',
          }}
          inputContainerStyle={{backgroundColor: 'white', height: 25}}
          onChangeText={text => handleSearch(text)}
          leftIconContainerStyle={{marginBottom: 8, marginRight: -7}}
          autoCorrect={false}
        />

        {props.options.length === 0 ? (
          <View style={{marginTop: 20}}>
            <MessageBlock
              message={'No Items Found'}
              style={{fontSize: 16, color: '#000', fontWeight: '500'}}
            />
          </View>
        ) : (
          <ScrollView
            contentContainerStyle={{flexGrow: 1}}
            showsVerticalScrollIndicator={false}
            style={styles.items}>
            {props.options.map((item, idx) => {
              if (item.sheetContent.sheet_no.toString().includes(query)) {
                return (
                  <SheetListItem
                    key={idx}
                    item={item}
                    handleItemPress={handleItemPress}></SheetListItem>
                );
              }
            })}
          </ScrollView>
        )}
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 10,
  },
  searchBar: {
    elevation: 0,
    borderColor: 'black',
    borderRadius: 2,
    marginTop: 5,
    backgroundColor: 'white',
  },
  items: {
    marginTop: 15,
    height: '88%',
  },
});

export default SheetList;
