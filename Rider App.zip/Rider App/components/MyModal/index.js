import Modal from 'react-native-modal';
import {View, Text, StyleSheet, Pressable} from 'react-native';
import {Divider} from 'react-native-paper';

const MyModal = props => {
  return (
    <Modal isVisible={true} on>
      <View style={styles.modal}>
        <Text style={styles.header}>{props.title || 'Message'}</Text>
        <Divider style={{color: 'black'}}></Divider>
        <Text
          style={[
            styles.content,
            {color: props.type === 'error' ? 'red' : 'green'},
          ]}>
          {props.content}
        </Text>

        <Pressable
          style={[styles.button, styles.buttonClose]}
          onPress={props.onModalClose}>
          <Text style={{color: 'white', fontWeight: '500'}}>OK</Text>
        </Pressable>
      </View>
    </Modal>
  );
};

export default MyModal;

const styles = StyleSheet.create({
  modal: {
    backgroundColor: 'white',
    padding: 15,
    height: 160,
    width: '95%',
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#fff',
    marginTop: 0,
    marginLeft: 10,
  },
  header: {
    fontSize: 18,
    fontWeight: '500',
    color: '#5A5A5A',
  },
  content: {
    marginTop: 10,
    fontSize: 14,
    fontWeight: '500',
    color: 'red',
  },
  button: {
    borderRadius: 15,
    padding: 10,
    marginLeft: 80,
    marginRight: 80,
    elevation: 2,
    alignItems: 'center',
    marginTop: 37,
  },
  buttonOpen: {
    backgroundColor: '#009387',
  },
  buttonClose: {
    backgroundColor: '#009387',
    padding: 10,
  },
});
