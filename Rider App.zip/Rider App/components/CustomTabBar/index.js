import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';
import {COLORS} from '../../resources/resources';
const FocusedGradient = ['#4c669f', '#3b5998', '#192f6a'];
const NotFocusedGradient = ['#ffffff', '#ffffff'];

function CustomTabBar({state, descriptors, navigation}) {
  const focusedOptions = descriptors[state.routes[state.index].key].options;

  if (focusedOptions.tabBarVisible === false) {
    return null;
  }

  return (
    <View style={{flexDirection: 'row'}}>
      {state.routes.map((route, index) => {
        const {options} = descriptors[route.key];
        const label =
          options.tabBarLabel !== undefined
            ? options.tabBarLabel
            : options.title !== undefined
            ? options.title
            : route.name;

        const isFocused = state.index === index;

        const onPress = () => {
          const event = navigation.emit({
            type: 'tabPress',
            target: route.key,
            canPreventDefault: true,
          });

          if (!isFocused && !event.defaultPrevented) {
            navigation.navigate(route.name);
          }
        };

        const onLongPress = () => {
          navigation.emit({
            type: 'tabLongPress',
            target: route.key,
          });
        };

        return (
          <View
            key={index}
            style={{
              flex: 1,
              backgroundColor: isFocused ? '#fff' : '#fff',
              borderTopWidth: 1.5,
              borderTopColor: isFocused ? COLORS.persianGreenColor : '#fff',
            }}>
            <TouchableOpacity
              accessibilityRole="button"
              accessibilityState={isFocused ? {selected: true} : {}}
              accessibilityLabel={options.tabBarAccessibilityLabel}
              testID={options.tabBarTestID}
              onPress={onPress}
              onLongPress={onLongPress}
              style={{
                minHeight: 50,
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              {label === 'Route' ? (
                <Icon
                  name={'location'}
                  size={18}
                  color={isFocused ? COLORS.persianGreenColor : 'grey'}
                />
              ) : (
                <Icon2
                  name={'package'}
                  size={18}
                  color={isFocused ? COLORS.persianGreenColor : 'grey'}
                />
              )}
              <Text
                style={{
                  fontSize: 11,
                  fontWeight: '600',
                  color: isFocused ? COLORS.persianGreenColor : 'grey',
                }}>
                {label}
              </Text>
            </TouchableOpacity>
          </View>
        );
      })}
    </View>
  );
}

export default CustomTabBar;
