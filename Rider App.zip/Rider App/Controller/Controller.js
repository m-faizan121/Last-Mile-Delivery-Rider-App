import {db} from '../config';
import {ref, onValue, push, update, remove} from 'firebase/database';
import Geocoder from 'react-native-geocoding';
import {API_KEYS} from '../resources/resources';
import axios from 'axios';

const mockData = {
  'Allied Bank Limited, Misrial 0919': {
    latitude: 33.60117789546947,
    longitude: 73.00003379757311,
  },
  'Maryam Memorial Hospital (MMH)': {
    latitude: 33.60435013324814,
    longitude: 73.02453009757318,
  },
  'QAU Islamabad': {
    latitude: 33.7485044065073,
    longitude: 73.13812099971878,
  },
  'Monal Rawalpindi': {
    latitude: 33.59523228525105,
    longitude: 73.05738684175239,
  },
  'Islamabad Serena Hotel': {
    latitude: 33.71570170914203,
    longitude: 73.10186053972342,
  },
  'Savour Foods, Jinnah Avenue, Block H G 7/2 Blue Area, Islamabad': {
    latitude: 33.71343561809232,
    longitude: 73.06338296671059,
  },
  'Bitsol Technologies, Islamabad': {
    latitude: 33.66461357237935,
    longitude: 73.05221269554461,
  },
  'Air University, E-9/4 E-9, Islamabad': {
    latitude: 33.714072940831365,
    longitude: 73.02467545506524,
  },
  'QAU Administration Block': {
    latitude: 33.748039219898786,
    longitude: 73.15118390946677,
  },
};

const mockedDistances = {
  'Islamabad Serena Hotel': {distance: 10.9, duration: 20},
  'Savour Foods, Jinnah Avenue, Block H G 7/2 Blue Area, Islamabad': {
    distance: 10.9,
    duration: 20,
  },
  'Bitsol Technologies, Islamabad': {distance: 19.2, duration: 29},
  'Air University, E-9/4 E-9, Islamabad': {distance: 21.1, duration: 34},
  'QAU Administration Block': {distance: 3.0, duration: 7},
};

// Initialize the module (needs to be done only once)

class Controller {
  // Private Members
  MAP_API_KEY;
  FIREBASE_URL;

  // Constructor
  constructor() {
    this.FIREBASE_URL = ''; // Firebase Reference
    this.MAP_API_KEY = '';
    Geocoder.init(API_KEYS.googleMapsKey); // use a valid API key
  }

  // Method to connect with Firebase
  connectToFirebase(url) {
    this.FIREBASE_URL = url; // Setting firebase reference
  }

  // Method to connect with Maps
  connectToMap(key) {
    this.MAP_API_KEY = key; // Setting map key
  }

  // Method to retrieve list of delivery sheet from database
  async retrieveDeliverySheet(DATABASE) {
    try {
      const response = await fetch(`${this.FIREBASE_URL}/${DATABASE}.json`);
      const sheets = await response.json();
      const data = [];
      for (const key in sheets) {
        data.push({sheetRef: key, sheetContent: sheets[key]});
      }
      return data;
    } catch (err) {
      alert('Error. Status Code ' + response.status);
      return null;
    }
  }

  // Convert address to coordinate
  async geocodeAddress(address) {
    return mockData[address];
    try {
      const json = await Geocoder.from(address);

      var location = json.results[0].geometry.location;
      return {
        latitude: location.lat,
        longitude: location.lng,
      };
    } catch (e) {
      alert('Something wents wrong in Geocoding!');
    }
  }

  async getDistanceAndDuration(origin, destination) {
    return mockedDistances[destination];
    try {
      const response = await axios.get(
        'https://maps.googleapis.com/maps/api/distancematrix/json',
        {
          params: {
            units: 'metric',
            origins: origin,
            destinations: destination,
            key: API_KEYS.googleMapsKey,
          },
        },
      );
      const data = response.data;
      if (data.status === 'OK') {
        const dist = data.rows[0].elements[0].distance.text;
        const dur = data.rows[0].elements[0].duration.text;
        const distance = parseFloat(dist.split(' ')[0]);
        const duration = parseFloat(dur.split(' ')[0]);
        return {distance, duration};
      } else {
        throw new Error(data.error_message);
      }
    } catch (error) {
      console.error(error);
    }
  }

  async getAddress(latitude, longitude) {
    return 'Department of Computer Science';
    try {
      const response = await axios.get(
        'https://maps.googleapis.com/maps/api/geocode/json',
        {
          params: {
            latlng: `${latitude},${longitude}`,
            key: API_KEYS.googleMapsKey,
          },
        },
      );
      const data = response.data;
      if (data.status === 'OK') {
        const address = data.results[0].formatted_address;
        return address;
      } else {
        throw new Error(data.error_message);
      }
    } catch (error) {
      console.error(error);
    }
  }

  async getAlternativeRoutes(origin, destination) {
    try {
      const response = await axios.get(
        'https://maps.googleapis.com/maps/api/directions/json',
        {
          params: {
            origin: origin,
            destination: destination,
            alternatives: true,
            key: API_KEYS.googleMapsKey,
          },
        },
      );
      const data = response.data;
      if (data.status === 'OK') {
        return data.routes;
      } else {
        throw new Error(data.error_message);
      }
    } catch (error) {
      console.error(error);
    }
  }
}

export default Controller;
