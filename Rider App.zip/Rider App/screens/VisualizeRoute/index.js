import {
  Text,
  ActivityIndicator,
  StyleSheet,
  Dimensions,
  TouchableHighlight,
  PermissionsAndroid,
  Image,
  TouchableOpacity,
} from 'react-native';
import {View} from 'react-native';
import {AuthContext} from '../../components/context';
import {useContext, useEffect, useState} from 'react';
import MapView from 'react-native-maps';
import {Marker} from 'react-native-maps';
import Geolocation from 'react-native-geolocation-service';
import MyModal from '../../components/MyModal';
import Controller from '../../Controller/Controller';
import Icon from 'react-native-vector-icons/Ionicons';
import {COLORS} from '../../resources/resources';
import MapViewDirections from 'react-native-maps-directions';
import {API_KEYS} from '../../resources/resources';
const ROUTE_COLORS = ['blue', 'green', 'black', 'yellow', 'black', 'orange'];
import AsyncStorage from '@react-native-async-storage/async-storage';

const controller = new Controller();

async function requestLocationPermission() {
  try {
    const granted = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
      {
        title: 'Location Permission',
        message:
          'This app needs access to your location to show your current location on the map.',
        buttonNeutral: 'Ask Me Later',
        buttonNegative: 'Cancel',
        buttonPositive: 'OK',
      },
    );
    if (granted === PermissionsAndroid.RESULTS.GRANTED) {
      console.log('You can use the location');
      return true;
    } else {
      console.log('Location permission denied');
      return false;
    }
  } catch (err) {
    console.warn(err);
    return false;
  }
}

const VisualizeRoute = ({params, refresh}) => {
  const {sheet} = params;
  const customersData = sheet.sheetContent.sheet;
  const [geocodedData, setGeocodedData] = useState([]);
  const [currentLocation, setCurrentLocation] = useState(null);
  const [locationPermission, setLocationPermission] = useState(true);
  const [route, setRoute] = useState(true);
  const {deliverySheet} = useContext(AuthContext);
  const [loading, setLoading] = useState(true);
  const [alternativeRoutes, setAlternativeRoutes] = useState([]);
  const [wayPoints, setWayPoints] = useState(undefined);
  const [currentStop, setCurrentStop] = useState(0);
  const [counts, setCounts] = useState(null);
  const [show, setShow] = useState(false);

  const changeCurrentStop = data => {
    let i = 0;
    while (i < data.length) {
      if (data[i].status === false) {
        setCurrentStop(i);
        return data[i].id;
      }
      i++;
    }
  };

  useEffect(() => {
    // setCurrentLocation({
    //   latitude: 33.74742796817325,
    //   longitude: 73.13723628223359,
    //   latitudeDelta: 0.01,
    //   longitudeDelta: 0.01,
    // });
    Geolocation.getCurrentPosition(
      position => {
        setCurrentLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        });
      },
      error => {
        setLocationPermission(false);
      },
      {enableHighAccuracy: true, timeout: 15000, maximumAge: 10000},
    );
  }, [customersData, refresh]);

  useEffect(() => {
    const geocodeAllData = async () => {
      if (Object.keys(customersData).length === 0) {
        setRoute(false);
        return;
      }

      const total = Object.keys(customersData).length;
      let delivered = 0;

      const data = [];

      const myAddress = await controller.getAddress(
        currentLocation.latitude,
        currentLocation.longitude,
      );
      for (const key in customersData) {
        if (customersData[key].status) {
          delivered++;
        }

        const coordinates = await controller.geocodeAddress(
          customersData[key].address,
        );
        const {distance, duration} = await controller.getDistanceAndDuration(
          myAddress,
          customersData[key].address,
        );
        data.push({
          ...customersData[key],
          cusRef: key,
          coordinates: coordinates,
          distance: distance,
          duration: duration,
        });
      }
      const stop = changeCurrentStop(
        data.sort((a, b) => {
          return a.distance - b.distance;
        }),
      );

      setWayPoints(undefined);
      setGeocodedData(
        data.sort((a, b) => {
          return a.distance - b.distance;
        }),
      );

      const routes = await AsyncStorage.getItem(stop);
      console.log(JSON.parse(routes));
      setAlternativeRoutes(JSON.parse(routes));
      setCounts({d: delivered, p: total - delivered});
      setLoading(false);
    };

    if (currentLocation) {
      setLoading(true);
      geocodeAllData();
    }
  }, [currentLocation, refresh]);

  function getWayPoints() {
    // if (geocodedData.length > 0) {
    //   return geocodedData.map(item => {
    //     return item.coordinates;
    //   });
    // }
    return undefined;
  }

  const onModalClose = () => {
    setLocationPermission(true);
    Geolocation.getCurrentPosition(
      position => {
        setCurrentLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        });
      },
      error => {
        setLocationPermission(false);
      },
      {enableHighAccuracy: true, timeout: 15000, maximumAge: 10000},
    );
  };

  const handleAlternativeRoute = (idx, dist, dur) => {
    const route = alternativeRoutes[idx];
    const steps = route.legs[0].steps;
    const waypoints = steps.map(item => {
      return {
        latitude: item.end_location.lat,
        longitude: item.end_location.lng,
      };
    });
    setWayPoints({way: waypoints, distance: dist, duration: dur});
  };

  console.log('I am on stop', currentStop);

  return (
    <View style={styles.container}>
      {/* {loading && <ActivityIndicator size="large" style={styles.loader} />} */}

      {!locationPermission && (
        <MyModal
          type={'error'}
          title={'Error'}
          content={'Location Permission is Denied!'}
          onModalClose={onModalClose}
        />
      )}
      {!route && locationPermission && (
        <MyModal
          type={'Message'}
          title={'Message'}
          content={'No Route Found!'}
          onModalClose={() => {
            setRoute(true);
          }}
        />
      )}
      {currentLocation && (
        <>
          <MapView
            showsTraffic={true}
            showsUserLocation={true}
            zoomEnabled={true}
            zoomControlEnabled={true}
            loadingEnabled={true}
            showsCompass={false}
            style={styles.map}
            onMapLoaded={() => {
              setLoading(false);
            }}
            onMapReady={() => {
              setLoading(false);
            }}
            initialRegion={currentLocation} //your region data goes here.
          >
            {currentLocation && (
              <Marker coordinate={currentLocation} style={styles.customMarker}>
                <View style={styles.addressBox}>
                  <TouchableOpacity onPress={() => console.log('Click!')}>
                    <Text style={styles.addressText}>
                      {'Department of Computer Science, QAU'}
                    </Text>
                  </TouchableOpacity>
                </View>
                <Image
                  style={{...styles.pin, width: 30, height: 30}}
                  source={require('../../assets/userPin.png')}
                />
              </Marker>
            )}
            {/*Make sure the Marker component is a child of MapView. Otherwise it won't render*/}
            {Object.keys(customersData).length > 0 &&
              geocodedData.map((item, idx) => {
                if (idx >= 0) {
                  return (
                    <Marker
                      key={idx}
                      coordinate={item.coordinates}
                      style={styles.customMarker}>
                      <View style={styles.addressBox}>
                        <TouchableOpacity onPress={() => console.log('Click!')}>
                          <Text style={styles.addressText}>
                            {item?.address}
                          </Text>
                          <View
                            style={{
                              borderColor: 'black',
                              borderTopWidth: 1,
                              marginTop: 5,
                              marginBottom: 5,
                            }}
                          />
                          <Text style={styles.distanceText}>
                            {idx === currentStop
                              ? wayPoints
                                ? `${wayPoints.distance} - ${wayPoints.duration}`
                                : `${item?.distance} km  -  ${item?.duration} mins`
                              : `${item?.distance} km  -  ${item?.duration} mins`}
                          </Text>
                        </TouchableOpacity>
                      </View>
                      <Image
                        style={styles.pin}
                        source={
                          item.status
                            ? require('../../assets/cusPin2.png')
                            : require('../../assets/cusPin.png')
                        }
                      />
                    </Marker>
                  );
                }
              })}

            {geocodedData && !loading && (
              <MapViewDirections
                origin={currentLocation}
                waypoints={wayPoints?.way}
                optimizeWaypoints={true}
                destination={geocodedData[currentStop].address}
                apikey={API_KEYS.googleMapsKey} // insert your API Key here
                strokeWidth={4}
                strokeColor={'blue'}
              />
            )}

            {/* 
            {geocodedData.map((item, idx) => {
              if (idx < geocodedData.length - 1) {
                return (
                  <MapViewDirections
                    key={idx}
                    origin={item.coordinates}
                    destination={geocodedData[idx + 1].coordinates}
                    apikey={API_KEYS.googleMapsKey} // insert your API Key here
                    strokeWidth={4}
                    strokeColor={ROUTE_COLORS[idx]}
                  />
                );
              }
            })} */}

            {/* {Object.keys(customersData).length > 0 && currentLocation && (
            <MapViewDirections
              origin={currentLocation}
              waypoints={getWayPoints()}
              destination={'Bitsol Islamabad'}
              apikey={API_KEYS.googleMapsKey} // insert your API Key here
              strokeWidth={2}
              strokeColor="blue"
            />
          )} */}
          </MapView>
          <TouchableOpacity
            style={styles.iconButton}
            activeOpacity={0.7}
            onPress={() => {
              setShow(!show);
            }}>
            <Image
              source={require('../../assets/alternative.png')}
              style={{width: 20, height: 20}}></Image>
          </TouchableOpacity>
          <View
            style={{
              flexDirection: 'column',
              position: 'absolute',
              bottom: 10,
              left: 10,
            }}>
            <View
              style={{
                flexDirection: 'row',
                backgroundColor: '#fff',
                paddingHorizontal: 10,
                paddingVertical: 5,
                borderRadius: 5,
                elevation: 5,
              }}>
              <Image
                source={require('../../assets/cusPin2.png')}
                style={{height: 20, width: 25}}
              />
              <Text style={{color: 'black', marginStart: 2, marginTop: 0}}>
                <Text>Delivered: </Text>
                {counts && (
                  <Text
                    style={{
                      color: 'green',
                      fontWeight: 'bold',
                    }}>{`${counts.d}`}</Text>
                )}
              </Text>
            </View>
            <View
              style={{
                flexDirection: 'row',
                backgroundColor: '#fff',
                paddingHorizontal: 10,
                paddingVertical: 5,
                borderRadius: 5,
                elevation: 5,
                marginTop: 5,
              }}>
              <Image
                source={require('../../assets/cusPin.png')}
                style={{height: 20, width: 25}}
              />
              <Text style={{color: 'black', marginStart: 2, marginTop: 0}}>
                <Text>Pending: </Text>
                {counts && (
                  <Text
                    style={{
                      color: 'red',
                      fontWeight: 'bold',
                    }}>{` ${counts.p}`}</Text>
                )}
              </Text>
            </View>
          </View>

          {show && (
            <View
              style={{
                flexDirection: 'column',
                position: 'absolute',
                top: 10,
                left: 0,
                backgroundColor: 'rgba(0, 0 ,0, 0.1)',
                paddingVertical: 10,
                paddingHorizontal: 5,
                width: 180,
                borderTopRightRadius: 10,
                borderBottomRightRadius: 10,
              }}>
              <Text
                style={{
                  color: 'black',
                  fontWeight: 'bold',
                  textAlign: 'center',
                }}>
                Alternatives
              </Text>
              {alternativeRoutes.map((item, idx) => {
                return (
                  <TouchableOpacity
                    key={idx}
                    style={styles.alternative}
                    activeOpacity={0.7}
                    onPress={() => {
                      handleAlternativeRoute(
                        idx,
                        item.legs[0].distance.text,
                        item.legs[0].duration.text,
                      );
                    }}>
                    <Text
                      style={{
                        color: COLORS.greenColor,
                        fontWeight: '600',
                        textAlign: 'center',
                      }}>
                      {item.legs[0].distance.text +
                        ' - ' +
                        item.legs[0].duration.text}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          )}
        </>
      )}
    </View>
  );
};

export default VisualizeRoute;

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    flex: 1, //the container will fill the whole screen.
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  iconButton: {
    position: 'absolute',
    top: 70,
    right: 12,
    backgroundColor: 'white',
    paddingTop: 8,
    paddingBottom: 8,
    paddingLeft: 9,
    paddingRight: 9,
    elevation: 5,
  },
  customMarker: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  addressBox: {
    maxWidth: 200,
    backgroundColor: COLORS.greenColor,
    paddingVertical: 5,

    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#fff',
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 5,
  },
  addressText: {
    paddingHorizontal: 7,
    textDecorationLine: 'none',
    fontWeight: '500',
    color: 'white',
    fontSize: 12.5,
  },
  distanceText: {
    paddingHorizontal: 7,
    textDecorationLine: 'none',
    fontWeight: '500',
    color: 'white',
    fontSize: 12.5,
  },
  pin: {
    width: 30,
    height: 30,
  },
  loader: {
    position: 'absolute',
  },
  alternative: {
    backgroundColor: 'white',
    paddingVertical: 10,
    marginEnd: 1,
    borderRadius: 5,
    elevation: 5,
    marginTop: 10,
    marginStart: 1,
    color: 'black',
    textAlign: 'center',
  },
});
