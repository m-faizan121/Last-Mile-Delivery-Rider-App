import React from 'react';
import {StyleSheet, View, Animated, ScrollView, Text} from 'react-native';
import {COLORS} from '../resources/resources';
import {SocialIcon} from 'react-native-elements';

const ContactScreen = props => {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.text_header}>Need Help ?</Text>
      </View>
      <Animated.View animation="fadeInUpBig" style={styles.footer}>
        <View>
          <Text style={{...styles.heading, marginTop: 10}}>Address</Text>
          <Text style={styles.paragraph}>
            Quaid-i-Azam University Islamabad
          </Text>
          <Text style={{...styles.heading, marginTop: 20}}>Phone</Text>
          <Text style={{...styles.paragraph}}>+92 304 5067949</Text>
          <Text style={{...styles.paragraph}}>+92 333 0343705</Text>
          <Text style={{...styles.heading, marginTop: 20}}>Email</Text>
          <Text style={{...styles.paragraph}}>mfaizan@bitsol.tech</Text>
          <Text style={{...styles.heading, marginTop: 20}}>Follow Us</Text>

          <View style={styles.socialMedia}>
            <SocialIcon
              title=""
              button
              type="whatsapp"
              iconColor="white"
              style={{...styles.socialIcons, backgroundColor: '#25D366'}}
            />
            <SocialIcon
              title=""
              button
              type="twitter"
              style={styles.socialIcons}
            />
            <SocialIcon
              title=""
              button
              type="facebook"
              style={styles.socialIcons}
            />
          </View>
        </View>
      </Animated.View>
    </View>
  );
};

export default ContactScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#e5e5e5',
  },
  header: {
    flex: 1,
    justifyContent: 'flex-end',
    paddingHorizontal: 20,
    paddingBottom: 50,
  },
  footer: {
    flex: Platform.OS === 'ios' ? 3 : 4,
    backgroundColor: '#fff',
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    paddingHorizontal: 20,
    paddingVertical: 30,
    paddingLeft: 25,
    paddingTop: 40,
  },
  text_header: {
    color: COLORS.greenColor,
    fontWeight: 'bold',
    fontSize: 30,
  },
  socialIcons: {
    width: 50,
    borderRadius: 30,
    elevation: 5,
    marginEnd: 10,
  },
  socialMedia: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 20,
  },
  heading: {
    color: 'black',
    fontSize: 20,
    fontWeight: '500',
    color: '#05375a',
  },
  paragraph: {
    fontSize: 15,
    marginTop: 10,
    fontFamily: 'arial',
  },
});
