import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  TouchableHighlight,
  Dimensions,
  StyleSheet,
  StatusBar,
  Image,
  Animated,
} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';

const SplashScreen = ({navigation}) => {
  const onPressHandler = () => {
    navigation.navigate('LoginScreen');
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Animated.Image
          animation="bounceIn"
          duraton="1500"
          source={require('../assets/logo2.png')}
          style={styles.logo}
          resizeMode="stretch"
        />
      </View>
      <Animated.View
        style={[
          styles.footer,
          {
            backgroundColor: 'white',
          },
        ]}
        animation="fadeInUpBig">
        <Text
          style={[
            styles.title,
            {
              color: '#05375a',
            },
          ]}>
          Welcome Rider!
        </Text>
        <Text style={styles.text}>Sign in with account</Text>

        <TouchableOpacity
          activeOpacity={0.7}
          style={styles.button}
          onPress={onPressHandler}>
          <Text
            style={{
              color: 'white',
              fontSize: 16,
              fontWeight: 'bold',
              textAlign: 'center',
              justifyContent: 'center',
            }}>
            Get Started
          </Text>
          <MaterialIcons name="navigate-next" color="#fff" size={20} />
        </TouchableOpacity>
      </Animated.View>
    </SafeAreaView>
  );
};

export default SplashScreen;

const {height} = Dimensions.get('screen');
const height_logo = height * 0.22;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#009387',
  },
  header: {
    flex: 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
  footer: {
    flex: 1,
    backgroundColor: '#fff',
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    paddingVertical: 50,
    paddingHorizontal: 30,
  },
  logo: {
    width: height_logo,
    height: height_logo,
    borderRadius: 20,
    marginTop: '-20%',
  },
  title: {
    color: '#05375a',
    fontSize: 30,
    fontWeight: 'bold',
  },
  text: {
    color: 'grey',
    marginTop: 5,
  },
  button: {
    backgroundColor: '#009387',
    padding: 14,
    borderRadius: 50,
    marginTop: 40,
    width: 150,
    color: 'white',
    elevation: 3,
    fontWeight: 'bold',
    flexDirection: 'row',
    alignItems: 'center',
    textAlign: 'center',
    justifyContent: 'center',
    marginLeft: '52%',
  },
  signIn: {
    width: 150,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 50,
    flexDirection: 'row',
    color: 'black',
  },
  textSign: {
    color: 'white',
    fontWeight: 'bold',
  },
});
