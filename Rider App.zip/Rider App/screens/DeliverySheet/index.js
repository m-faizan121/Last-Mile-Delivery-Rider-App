import {
  Text,
  View,
  ActivityIndicator,
  StyleSheet,
  ScrollView,
  Dimensions,
} from 'react-native';
import SheetList from '../../components/SheetList';
import {AuthContext} from '../../components/context';
import {useContext, useEffect, useState} from 'react';
import {TouchableOpacity} from 'react-native-gesture-handler';
import {COLORS} from '../../resources/resources';
import {SearchBar} from 'react-native-elements';
import MessageBlock from '../../components/MessageBlock';
import SheetListItem from '../../components/SheetList/SheetListItem';
import Icon from 'react-native-vector-icons/Ionicons';
import OptionMenu from '../../components/OptionMenu';

const DeliverySheet = props => {
  const [options, setOptions] = useState([]);
  const {deliverySheet, user} = useContext(AuthContext);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');

  console.log('render', deliverySheet.length);

  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      const filteredSheet = deliverySheet.filter(item => {
        console.log('user', user);
        return item.sheetContent.rider_id === user.username;
      });
      setOptions(
        // Sorting sheet by date
        filteredSheet.sort((a, b) => {
          return new Date(b.sheetContent.date) - new Date(a.sheetContent.date);
        }),
      );
      setLoading(false);
    }, 2000);
  }, [deliverySheet]);

  const handleSearch = value => {
    setQuery(value);
  };

  const handleItemPress = item => {
    props.navigation.navigate('MainTabScreen', {
      sheet: item,
    });
  };

  return (
    <View style={styles.container}>
      <SearchBar
        placeholder="Search Delivery Sheet"
        value={query}
        inputStyle={{backgroundColor: 'white', fontSize: 17}}
        containerStyle={{
          backgroundColor: 'white',
          borderWidth: 1,
          borderRadius: 5,
          elevation: 3,
          marginTop: 3,
          borderColor: 'white',
          borderBottomColor: 'white',
          borderTopColor: 'white',
        }}
        inputContainerStyle={{backgroundColor: 'white', height: 25}}
        onChangeText={text => handleSearch(text)}
        leftIconContainerStyle={{
          marginBottom: 8,
          marginRight: -7,
        }}
        rightIconContainerStyle={{
          marginTop: -1,
        }}
        autoCorrect={false}
      />

      {!loading && options.length > 0 && (
        <Text style={styles.itemsCount}>
          <Text style={{color: 'black'}}>{'Total:  '}</Text>
          <Text style={{color: 'black'}}>{options.length}</Text>
        </Text>
      )}

      {loading && <ActivityIndicator size="large" style={styles.loader} />}

      {!loading && deliverySheet.length === 0 && (
        <View style={{marginTop: 20}}>
          <MessageBlock
            message={'No Items Found'}
            style={{fontSize: 16, color: '#31FF39', fontWeight: '500'}}
          />
        </View>
      )}

      {!loading && options.length > 0 && (
        <ScrollView
          contentContainerStyle={{flexGrow: 1}}
          showsVerticalScrollIndicator={false}
          style={styles.items}>
          {options.map((item, idx) => {
            if (item.sheetContent.sheet_no.includes(query)) {
              return (
                <SheetListItem
                  key={idx}
                  item={item}
                  handleItemPress={handleItemPress}></SheetListItem>
              );
            }
          })}
        </ScrollView>
      )}

      <View style={styles.bottomTab}>
        <Icon
          style={{textAlign: 'center'}}
          name={'ios-list'}
          color={COLORS.persianGreenColor}
          size={18}
        />
        <Text
          style={{
            textAlign: 'center',
            fontSize: 12,
            fontWeight: '600',
            color: COLORS.persianGreenColor,
          }}>
          {'Delivery Sheets'}
        </Text>
      </View>
    </View>
  );
};

export default DeliverySheet;

const styles = StyleSheet.create({
  loader: {
    marginTop: 50,
  },
  container: {
    padding: 10,
    backgroundColor: '#e5e5e5',
    flex: 1,
  },
  searchBar: {
    elevation: 0,
    borderColor: 'black',
    borderRadius: 2,
    marginTop: 5,
    backgroundColor: 'white',
  },
  items: {
    height: '88%',
    marginTop: 3,
  },
  bottomTab: {
    width: Dimensions.get('window').width,
    padding: '2%',
    backgroundColor: '#fff',
    position: 'absolute',
    bottom: 0,
    borderTopColor: COLORS.persianGreenColor,
    borderTopWidth: 1,
    elevation: 3,
  },
  itemsCount: {
    textAlign: 'right',
    marginTop: 7,
    marginEnd: 5,
    fontSize: 12,
    fontWeight: 'bold',
  },
});
