import React from 'react';
import {
  StyleSheet,
  View,
  Animated,
  ScrollView,
  Text,
  Image,
} from 'react-native';
import {COLORS} from '../resources/resources';
import {SocialIcon} from 'react-native-elements';

const ContactScreen = props => {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.text_header}>Who We Are ?</Text>
      </View>
      <Animated.View animation="fadeInUpBig" style={styles.footer}>
        <ScrollView showsVerticalScrollIndicator={false}>
          <Text style={{...styles.heading, marginTop: 10}}>ORPAI</Text>
          <Text style={styles.paragraph}>
            Optimal Route Planning through Artificial Intelligence
          </Text>
          <Text style={{...styles.heading, marginTop: 20}}>
            Last Mile Delivery
          </Text>
          <Text style={{...styles.paragraph, textAlign: 'justify'}}>
            Last mile delivery, also known as last mile logistics, is the
            transportation of goods from a distribution hub to the final
            delivery destination — the door of the customer. The goal of last
            mile delivery logistics is to deliver the packages as affordably,
            quickly and accurately as possible.
          </Text>
          <Image
            style={styles.tinyLogo}
            source={require('../assets/deliveryies.png')}
          />
        </ScrollView>
      </Animated.View>
    </View>
  );
};

export default ContactScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#e5e5e5',
  },
  header: {
    flex: 1,
    justifyContent: 'flex-end',
    paddingHorizontal: 20,
    paddingBottom: 50,
  },
  tinyLogo: {
    width: '100%',
    height: 200,
    elevation: 5,
  },
  footer: {
    flex: Platform.OS === 'ios' ? 3 : 4,
    backgroundColor: '#fff',
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    paddingHorizontal: 20,
    paddingVertical: 30,
    paddingLeft: 25,
    paddingRight: 25,
    paddingTop: 40,
  },
  text_header: {
    color: COLORS.greenColor,
    fontWeight: 'bold',
    fontSize: 30,
  },
  socialIcons: {
    width: 50,
    borderRadius: 30,
    elevation: 5,
  },
  socialMedia: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 20,
  },
  heading: {
    color: 'black',
    fontSize: 20,
    fontWeight: '500',
    color: '#05375a',
  },
  paragraph: {
    fontSize: 15,
    marginTop: 10,
    fontFamily: 'arial',
  },
});
