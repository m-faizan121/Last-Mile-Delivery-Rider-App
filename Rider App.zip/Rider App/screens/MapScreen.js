import * as React from 'react';
import {useContext} from 'react';
import {AuthContext} from '../components/context';
import {Text} from 'react-native';

const MyTheme = {
  dark: false,
  colors: {
    primary: 'rgb(11, 97, 83 )',
    background: 'rgb(255, 255, 255)',
    card: 'rgba(0,161,166,255)',
    text: 'rgb(255,255,255)',
    border: 'rgb(199, 199, 204)',
  },
};

const MapScreen = ({navigation}) => {
  const {user} = useContext(AuthContext);

  return <Text>{`Hey ${user}`}</Text>;
};

export default MapScreen;
