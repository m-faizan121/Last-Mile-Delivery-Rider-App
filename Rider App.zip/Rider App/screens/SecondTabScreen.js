import React from 'react';

import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {createNativeStackNavigator} from '@react-navigation/native-stack';

import Icon from 'react-native-vector-icons/Ionicons';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';
import VisualizeRoute from './VisualizeRoute';
import DeliverySheet from './DeliverySheet';
import CustomersScreen from './CustomersScreen';
import CustomTabBar from '../components/CustomTabBar';

const RouteStack = createNativeStackNavigator();

const RouteStackScreen = ({navigation}) => (
  <RouteStack.Navigator>
    <RouteStack.Screen
      name="Route"
      component={DeliverySheet}
      options={{
        title: 'Route',
        headerLeft: () => (
          <Icon
            name="arrow-back"
            size={25}
            backgroundColor={'#009387'}
            color={'black'}
            style={{marginTop: 4, marginLeft: 0, marginRight: 10}}
            onPress={() => navigation.navigate('DeliverySheet')}></Icon>
        ),
      }}
    />
  </RouteStack.Navigator>
);

const CustomersStack = createNativeStackNavigator();
const CustomersStackScreen = ({navigation}) => (
  <CustomersStack.Navigator initialRouteName="DeliverySheet">
    <CustomersStack.Screen
      name="Customers"
      component={VisualizeRoute}
      options={{
        title: 'Customers',
        headerLeft: () => (
          <Icon
            name="arrow-back"
            size={25}
            backgroundColor={'#009387'}
            color={'black'}
            style={{marginTop: 4, marginLeft: 0, marginRight: 10}}
            onPress={() => navigation.navigate('DeliverySheet')}></Icon>
        ),
      }}
    />
  </CustomersStack.Navigator>
);

// -------------------- TAB NAVIGATION -------------------------- //

const Tab = createBottomTabNavigator();
const SecondTabScreen = () => (
  <Tab.Navigator
    tabBar={props => (
      <CustomTabBar {...props} screenOptions={{headerShown: false}} />
    )}>
    <Tab.Screen
      name="Route"
      component={RouteStackScreen}
      options={{headerShown: false}}
    />
    <Tab.Screen
      name="Customers"
      component={CustomersStackScreen}
      options={{headerShown: false}}
    />
  </Tab.Navigator>
);

export default SecondTabScreen;
