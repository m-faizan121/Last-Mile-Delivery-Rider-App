import 'react-native-gesture-handler';
import {
  StyleSheet,
  Text,
  View,
  ImageBackground,
  Dimensions,
} from 'react-native';
import {memo, useCallback} from 'react';

import {useState} from 'react';

import {NavigationContainer, DefaultTheme} from '@react-navigation/native';
import {createDrawerNavigator} from '@react-navigation/drawer';
// import VisualizeRoute from "../VisualizeRoute";
// import DeliverySheet from "../DeliverySheet";
// import Widget from "../../.expo/widget/Widget";
import {DrawerContent} from './DrawerContent';
import {useEffect} from 'react';
import VisualizeRoute from '../VisualizeRoute';
import DeliverySheet from '../DeliverySheet';

const Drawer = createDrawerNavigator();
// const widget = new Widget(
//   "https://orpai-a2066-default-rtdb.firebaseio.com",
//   "DeliverySheet"
// );

function MyDrawer() {
  return (
    <Drawer.Navigator
      useLegacyImplementation
      drawerContentOptions={{
        activeTintColor: 'blue',
        itemStyle: {marginVertical: 8, marginHorizontal: 8},
      }}
      drawerContent={props => <DrawerContent {...props} />}>
      <Drawer.Screen name="My Route" component={() => <VisualizeRoute />} />
      <Drawer.Screen
        name="Delivery Sheet"
        component={() => <DeliverySheet />}
      />
    </Drawer.Navigator>
  );
}

const MyTheme = {
  dark: false,
  colors: {
    primary: 'rgb(11, 97, 83 )',
    background: 'rgb(255, 255, 255)',
    card: 'rgba(0,161,166,255)',
    text: 'rgb(255,255,255)',
    border: 'rgb(199, 199, 204)',
  },
};

const RiderHome = props => {
  return <MyDrawer />;
};

export default memo(RiderHome);
