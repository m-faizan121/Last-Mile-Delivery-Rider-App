import React from 'react';
import {View, StyleSheet} from 'react-native';
import {
  useTheme,
  Avatar,
  Title,
  Caption,
  Paragraph,
  Drawer,
  Text,
  TouchableRipple,
  Switch,
  Divider,
} from 'react-native-paper';
import {DrawerContentScrollView, DrawerItem} from '@react-navigation/drawer';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {COLORS} from '../../resources/resources';
import {useContext} from 'react';
import {AuthContext} from '../../components/context';

export function DrawerContent(props) {
  const {user} = useContext(AuthContext);
  console.log(user);

  return (
    <View style={{flex: 1}}>
      <DrawerContentScrollView
        {...props}
        scrollEnabled={false}
        showsVerticalScrollIndicator={false}>
        <View style={styles.drawerContent}>
          <View style={styles.userInfoSection}>
            <View style={{flexDirection: 'row', marginTop: 25}}>
              <Avatar.Image
                style={{backgroundColor: 'white'}}
                source={{
                  uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSizvOLIal0Zq7EJXLvVe2dJ5gwHObXR6lb3Rp-8OEYA5TG-Czz77ssQfVnPYu7q00auTU&usqp=CAU',
                }}
                size={60}
              />
              <View style={{marginLeft: 15, flexDirection: 'column'}}>
                <Title style={styles.title}>
                  {user?.name || 'Muhammad Faizan'}
                </Title>
                <Caption style={styles.caption}>
                  {user?.username || 'faizee000'}
                </Caption>
              </View>
            </View>
          </View>

          <Drawer.Section style={styles.drawerSection} showDivider={false}>
            <DrawerItem
              style={{marginLeft: 20, marginTop: 30}}
              icon={({color, size}) => (
                <Icon name="view-list" color={COLORS.greenColor} size={22} />
              )}
              label="Delivery Sheets"
              labelStyle={{color: 'black', marginBottom: 1}}
              onPress={() => {
                props.navigation.navigate('DeliverySheet');
              }}
            />
            <DrawerItem
              style={{marginLeft: 20}}
              icon={({color, size}) => (
                <Icon name="information" color={COLORS.greenColor} size={22} />
              )}
              label="About Us"
              labelStyle={{color: 'black', marginBottom: 1}}
              onPress={() => {
                props.navigation.navigate('AboutScreen');
              }}
            />
            <DrawerItem
              style={{marginLeft: 20}}
              icon={({color, size}) => (
                <Icon name="phone" color={COLORS.greenColor} size={22} />
              )}
              label="Contact Us"
              labelStyle={{color: 'black'}}
              onPress={() => {
                props.navigation.navigate('ContactScreen');
              }}
            />
            <View
              style={{
                borderColor: 'black',
                borderTopWidth: 0.7,
                marginTop: 10,
              }}
            />

            <DrawerItem
              style={{marginLeft: 20}}
              icon={({color, size}) => (
                <Icon name="exit-to-app" color={COLORS.greenColor} size={22} />
              )}
              labelStyle={{color: 'black'}}
              label="Sign Out"
              onPress={props.onSignOut}
            />
            {/* <View
              style={{
                borderColor: 'black',
                borderTopWidth: 0.7,
                marginTop: 0,
              }}
            /> */}
          </Drawer.Section>
        </View>
      </DrawerContentScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  drawerContent: {
    flex: 1,
  },
  userInfoSection: {
    paddingLeft: 20,
  },
  title: {
    fontSize: 17,
    marginTop: 2,
    fontWeight: '500',
    color: 'white',
  },
  caption: {
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 13,
    color: '#E8ECEF',
    marginLeft: 1,
  },
  row: {
    marginTop: 20,
    flexDirection: 'row',
    alignItems: 'center',
  },
  section: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 15,
  },
  paragraph: {
    fontWeight: 'bold',
    marginRight: 3,
  },
  drawerSection: {
    marginTop: 50,
    borderBottomColor: '#ffff',
    borderBottomWidth: 1,
    backgroundColor: 'white',
    marginLeft: 7,
    borderTopLeftRadius: 12,
    minHeight: 1000,
  },
  bottomDrawerSection: {
    marginBottom: 15,
    borderTopColor: '#ffff',
    borderTopWidth: 1,
    borderBottomColor: '#ffff',
    borderBottomWidth: 1,
    marginLeft: 0,
  },
  preference: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
});
