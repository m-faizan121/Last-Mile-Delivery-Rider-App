import {
  Text,
  View,
  ActivityIndicator,
  StyleSheet,
  ScrollView,
  Dimensions,
} from 'react-native';
import {SearchBar} from 'react-native-elements';
import {SafeAreaView} from 'react-native-safe-area-context';
import {AuthContext} from '../../components/context';
import {useContext, useEffect, useState} from 'react';
import CustomerList from '../../components/CustomerList';
import CustomerListItem from '../../components/CustomerList/CustomerListItem';
import MessageBlock from '../../components/MessageBlock';
import {db} from '../../config';
import {ref, onValue, push, update, remove} from 'firebase/database';
import Geolocation from 'react-native-geolocation-service';
import Controller from '../../Controller/Controller';
import ConsignmentModal from '../../components/ConsignmentModal';
import MyModal from '../../components/MyModal';

function formatAMPM(date) {
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours >= 12 ? 'pm' : 'am';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? '0' + minutes : minutes;
  var strTime = hours + ':' + minutes + ' ' + ampm;
  const today =
    date.getDate() + '-' + (date.getMonth() + 1) + '-' + date.getFullYear();
  return today + ', ' + strTime;
}

const controller = new Controller();

const CustomersScreen = ({params, refresh}) => {
  const {sheet} = params;
  const customersData = sheet.sheetContent.sheet;

  const [options, setOptions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const {updateStatus} = useContext(AuthContext);
  const [currentLocation, setCurrentLocation] = useState(null);
  const [modalData, setModalData] = useState(null);
  const [modal, setModal] = useState('');

  const checkBoxEvent = data => {
    let newDate = '';
    if (!data.status) newDate = formatAMPM(new Date());

    try {
      update(ref(db, `/DeliverySheets/${params.sheet.sheetRef}/sheet`), {
        [data.cusRef]: {
          id: data.id,
          name: data.name,
          address: data.address,
          status: !data.status,
          contact: data.contact,
          description: data.description,
          category: data.category,
          consignment_no: data.consignment_no,
          delivery_date: newDate,
        },
      }).then(() => {
        const newSheet = options.map(item => {
          if (item.id === data.id) {
            item.status = !item.status;
            item.delivery_date = newDate;
            return item;
          } else {
            return item;
          }
        });
        setOptions(newSheet);
        setModal('Status Updated Successfully!');
        updateStatus(params.sheet.sheetRef, data.cusRef, newDate);
      });
    } catch (exception) {
      console.error(exception);
      alert('Something Went Wrong!');
    }
  };

  useEffect(() => {
    // setCurrentLocation({
    //   latitude: 33.74742796817325,
    //   longitude: 73.13723628223359,
    //   latitudeDelta: 0.01,
    //   longitudeDelta: 0.01,
    // });
    Geolocation.getCurrentPosition(
      position => {
        setCurrentLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        });
      },
      error => {
        setLocationPermission(false);
      },
      {enableHighAccuracy: true, timeout: 15000, maximumAge: 10000},
    );
  }, [customersData, refresh]);

  useEffect(() => {
    setQuery('');

    const prepareConsignments = async () => {
      const myAddress = await controller.getAddress(
        currentLocation.latitude,
        currentLocation.longitude,
      );
      console.log(myAddress);
      const data = [];
      for (const key in customersData) {
        const {distance, duration} = await controller.getDistanceAndDuration(
          myAddress,
          customersData[key].address,
        );
        // console.log(distance, duration);
        data.push({
          ...customersData[key],
          cusRef: key,
          distance: distance,
          duration: duration,
        });
      }
      // await controller.getAlternativeRoutes(myAddress, data[3].address);
      setOptions(
        data.sort((a, b) => {
          return a.distance - b.distance;
        }),
      );
    };

    if (currentLocation) {
      console.log('loading');
      setLoading(true);
      setTimeout(() => {
        prepareConsignments();
        setLoading(false);
      }, 2000);
    }
  }, [params, currentLocation, refresh]);
  // Return the function to unsubscribe from the event so it gets removed on unmount

  const handleSearch = value => {
    setQuery(value);
  };

  const handleItemPress = item => {
    navigation.push('CustomersScreen', {
      sheet: item,
    });
  };

  const onModalClose = () => {
    setModal('');
  };

  return (
    <View style={styles.container}>
      {modal !== '' && (
        <MyModal
          type={'Message'}
          title={'Message'}
          content={modal}
          onModalClose={onModalClose}
        />
      )}
      {modalData && (
        <ConsignmentModal
          data={modalData}
          onModalClose={() => {
            console.log('close');
            setModalData(null);
          }}
        />
      )}
      <SearchBar
        placeholder="Search Consignment"
        value={query}
        inputStyle={{backgroundColor: 'white', fontSize: 17}}
        containerStyle={{
          backgroundColor: 'white',
          borderWidth: 1,
          borderRadius: 5,
          elevation: 3,
          marginTop: 3,
          borderColor: 'white',
          borderBottomColor: 'white',
          borderTopColor: 'white',
        }}
        inputContainerStyle={{backgroundColor: 'white', height: 25}}
        onChangeText={text => handleSearch(text)}
        leftIconContainerStyle={{
          marginBottom: 8,
          marginRight: -7,
        }}
        rightIconContainerStyle={{
          marginTop: -1,
        }}
        autoCorrect={false}
      />

      {!loading && options.length > 0 && (
        <Text style={styles.itemsCount}>
          <Text style={{color: 'black'}}>{'Total:  '}</Text>
          <Text style={{color: 'black'}}>{options.length}</Text>
        </Text>
      )}

      {loading && <ActivityIndicator size="large" style={styles.loader} />}

      {!loading && options.length === 0 && (
        <View style={{marginTop: 20}}>
          <MessageBlock
            message={'No Items Found'}
            style={{
              fontSize: 16,
              color: '#000',
              fontWeight: '500',
              color: '#31FF39',
            }}
          />
        </View>
      )}

      {!loading && options.length > 0 && (
        <ScrollView
          contentContainerStyle={{flexGrow: 1}}
          showsVerticalScrollIndicator={false}
          style={styles.items}>
          {options.map((item, idx) => {
            if (item.consignment_no.includes(query)) {
              return (
                <CustomerListItem
                  key={idx}
                  id={item.id}
                  name={item.name}
                  address={item.address}
                  status={item.status}
                  cusRef={item.cusRef}
                  contact={item.contact}
                  description={item.description}
                  category={item.category}
                  delivery_date={item.delivery_date}
                  consignment_no={item.consignment_no}
                  checkBoxEvent={checkBoxEvent}
                  onClick={() => {
                    setModalData(item);
                  }}
                />
              );
            }
          })}
        </ScrollView>
      )}
    </View>
  );
};

export default CustomersScreen;

const styles = StyleSheet.create({
  container: {
    padding: 10,
    backgroundColor: '#e5e5e5',
    flex: 1,
  },
  searchBar: {
    elevation: 0,
    borderColor: 'black',
    borderRadius: 2,
    marginTop: 5,
    backgroundColor: 'white',
  },
  items: {
    height: '88%',
    marginTop: 3,
  },
  loader: {
    marginTop: 50,
  },
  bottomTab: {
    width: Dimensions.get('screen').width,
    padding: '5%',
    backgroundColor: '#fff',
  },
  itemsCount: {
    textAlign: 'right',
    marginTop: 7,
    marginEnd: 5,
    fontSize: 12,
    fontWeight: 'bold',
  },
});
