import React, {useState} from 'react';

import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {useContext} from 'react';
import Icon from 'react-native-vector-icons/Ionicons';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';
import VisualizeRoute from './VisualizeRoute';
import DeliverySheet from './DeliverySheet';
import {Text, BackHandler} from 'react-native';
import CustomersScreen from './CustomersScreen';
import CustomTabBar from '../components/CustomTabBar';
import {MenuProvider} from 'react-native-popup-menu';
import {
  Menu,
  MenuOptions,
  MenuOption,
  MenuTrigger,
} from 'react-native-popup-menu';
const DeliverySheetStack = createNativeStackNavigator();

const DeliverySheetStackScreen = ({params, navigation, route}) => {
  const [refresh, setRefresh] = useState(false);
  console.log(refresh);
  return (
    <DeliverySheetStack.Navigator>
      <DeliverySheetStack.Screen
        name="Consignments"
        children={() => <CustomersScreen params={params} refresh={refresh} />}
        options={{
          headerTitleStyle: {fontSize: 18},
          title: 'Consignments',
          headerLeft: () => (
            <Icon
              name="arrow-back"
              size={23}
              backgroundColor={'#009387'}
              color={'white'}
              style={{marginTop: 3, marginLeft: 0, marginRight: 15}}
              onPress={() => {
                //navigation.reset();
                navigation.navigate('DeliverySheet');
              }}></Icon>
          ),
          headerRight: () => (
            <Menu>
              <MenuTrigger>
                <Icon
                  name="ellipsis-vertical"
                  size={18}
                  backgroundColor={'#009387'}
                  color={'white'}
                  style={{
                    marginTop: 4,
                    marginLeft: 0,
                    marginRight: 0,
                  }}
                />
              </MenuTrigger>
              <MenuOptions
                optionsContainerStyle={{
                  padding: 10,
                  borderRadius: 5,
                  width: 150,
                  marginLeft: -12,
                }}>
                <MenuOption
                  onSelect={() => {
                    setRefresh(!refresh);
                  }}
                  style={{display: 'flex', flexDirection: 'row'}}>
                  <Icon
                    name="md-refresh-outline"
                    color="black"
                    size={15}
                    style={{marginTop: 2, marginRight: 5}}
                  />
                  <Text style={{color: 'black', fontWeight: '400'}}>
                    Refresh
                  </Text>
                </MenuOption>

                <MenuOption
                  onSelect={() => {
                    BackHandler.exitApp();
                  }}
                  style={{
                    display: 'flex',
                    flexDirection: 'row',
                    marginTop: 5,
                  }}>
                  <Icon
                    name="close"
                    color="black"
                    size={15}
                    style={{marginTop: 2, marginRight: 5}}
                  />
                  <Text style={{color: 'black', fontWeight: '400'}}>
                    Close App
                  </Text>
                </MenuOption>
              </MenuOptions>
            </Menu>
          ),
        }}
      />
    </DeliverySheetStack.Navigator>
  );
};

const RouteStack = createNativeStackNavigator();
const RouteStackScreen = ({params, navigation}) => {
  const [refresh, setRefresh] = useState(false);
  console.log(refresh, 'route');
  return (
    <RouteStack.Navigator>
      <RouteStack.Screen
        name="Route"
        children={() => <VisualizeRoute params={params} refresh={refresh} />}
        options={{
          headerTitleStyle: {fontSize: 18},
          title: 'Route',
          headerLeft: () => (
            <Icon
              name="arrow-back"
              size={23}
              backgroundColor={'#009387'}
              color={'white'}
              style={{marginTop: 3, marginLeft: 0, marginRight: 15}}
              onPress={() => {
                //navigation.reset();
                navigation.goBack();
              }}></Icon>
          ),
          headerRight: () => (
            <Menu>
              <MenuTrigger>
                <Icon
                  name="ellipsis-vertical"
                  size={18}
                  backgroundColor={'#009387'}
                  color={'white'}
                  style={{
                    marginTop: 4,
                    marginLeft: 0,
                    marginRight: 0,
                  }}
                />
              </MenuTrigger>
              <MenuOptions
                optionsContainerStyle={{
                  padding: 10,
                  borderRadius: 5,
                  width: 150,
                  marginLeft: -12,
                }}>
                <MenuOption
                  onSelect={() => {
                    setRefresh(!refresh);
                  }}
                  style={{display: 'flex', flexDirection: 'row'}}>
                  <Icon
                    name="md-refresh-outline"
                    color="black"
                    size={15}
                    style={{marginTop: 2, marginRight: 5}}
                  />
                  <Text style={{color: 'black', fontWeight: '400'}}>
                    Refresh
                  </Text>
                </MenuOption>

                <MenuOption
                  onSelect={() => {
                    BackHandler.exitApp();
                  }}
                  style={{
                    display: 'flex',
                    flexDirection: 'row',
                    marginTop: 5,
                  }}>
                  <Icon
                    name="close"
                    color="black"
                    size={15}
                    style={{marginTop: 2, marginRight: 5}}
                  />
                  <Text style={{color: 'black', fontWeight: '400'}}>
                    Close App
                  </Text>
                </MenuOption>
              </MenuOptions>
            </Menu>
          ),
        }}
      />
    </RouteStack.Navigator>
  );
};

// -------------------- TAB NAVIGATION -------------------------- //

const Tab = createBottomTabNavigator();
const MainTabScreen = ({navigation, route}) => {
  return (
    <Tab.Navigator
      tabBar={props => (
        <CustomTabBar {...props} screenOptions={{headerShown: false}} />
      )}>
      <Tab.Screen
        name="ConsignmentsScreen"
        children={() => (
          <DeliverySheetStackScreen
            params={route.params}
            navigation={navigation}
          />
        )}
        options={{headerShown: false, tabBarLabel: 'Consignments'}}
      />
      <Tab.Screen
        name="RouteScreen"
        children={() => (
          <RouteStackScreen params={route.params} navigation={navigation} />
        )}
        options={{headerShown: false, tabBarLabel: 'Route'}}
      />
    </Tab.Navigator>
  );
};

export default MainTabScreen;
