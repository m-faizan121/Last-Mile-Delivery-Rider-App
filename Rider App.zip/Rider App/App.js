/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import * as React from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {Text, BackHandler} from 'react-native';

import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import RootStack from './stacks/RootStack';
import RiderStack from './stacks/RiderStack';
import Spinner from 'react-native-loading-spinner-overlay';

import {
  Provider as PaperProvider,
  DefaultTheme as PaperDefaultTheme,
  DarkTheme as PaperDarkTheme,
} from 'react-native-paper';
import {AuthContext} from './components/context';

import {createDrawerNavigator} from '@react-navigation/drawer';
import {StatusBar} from 'react-native';
import {DrawerContent} from './screens/RiderHome/DrawerContent';
import MainTabScreen from './screens/MainTabScreen';
import Icon from 'react-native-vector-icons/Ionicons';
import Controller from './Controller/Controller';
import DeliverySheet from './screens/DeliverySheet';
import {MenuProvider} from 'react-native-popup-menu';
import {
  Menu,
  MenuOptions,
  MenuOption,
  MenuTrigger,
} from 'react-native-popup-menu';
import {COLORS} from './resources/resources';
import {SafeAreaProvider} from 'react-native-safe-area-context';
import AboutScreen from './screens/AboutScreen';
import ContactScreen from './screens/ContactScreen';

const MyTheme = {
  dark: false,
  colors: {
    primary: COLORS.greenColor,
    background: 'rgb(255, 255, 255)',
    card: COLORS.greenColor,
    text: 'rgb(255,255,255)',
    border: 'rgb(199, 199, 204)',
  },
};

const Drawer = createDrawerNavigator();

const controller = new Controller();
controller.connectToFirebase(
  'https://route-visualization-app-default-rtdb.firebaseio.com/',
);

const App = () => {
  const [user, setUser] = React.useState(null);
  const [deliverySheet, setDeliverySheet] = React.useState([]);
  const [update, setUpdate] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [refresh, setRefresh] = React.useState(true);

  // Provided in context
  const updateStatus = (sheetRef, cusRef, date) => {
    console.log(date);
    let sheet = [...deliverySheet];
    const newSheet = sheet.map(item => {
      if (item.sheetRef === sheetRef) {
        console.log(item.sheetContent.sheet[cusRef]);
        item.sheetContent.sheet[cusRef].status =
          !item.sheetContent.sheet[cusRef].status;
        item.sheetContent.sheet[cusRef].delivery_date = date;
      }
      return item;
    });
    setDeliverySheet(newSheet);
  };

  React.useEffect(() => {
    controller
      .retrieveDeliverySheet('DeliverySheets')
      .then(sheet => {
        console.log(sheet);
        setDeliverySheet(sheet);
      })
      .catch(e => {
        console.log(e);
      });
    // controller
    //   .getAlternativeRoutes('QAU Islamabad', 'QAU Administration Block')
    //   .then(routes => {
    //     AsyncStorage.setItem('c105', JSON.stringify(routes)).then(() => {
    //       console.log('Saved5 ...');
    //     });
    //   });
    // AsyncStorage.getItem('route_1').then(route => {
    //   console.log(route);
    //   // console.log(JSON.parse(route)[0].legs[0].steps);
    // });
  }, [refresh]);

  React.useEffect(() => {
    AsyncStorage.getItem('user').then(user => {
      setUser(JSON.parse(user));
    });
  }, []);

  const handleSignOut = () => {
    setLoading(true);
    setTimeout(() => {
      setUser(null);
      AsyncStorage.removeItem('user').then(() => {
        setLoading(false);
      });
      setLoading(false);
    }, 2000);
  };

  const handleRefreshDeliverySheet = () => {
    //setDeliverySheet([]);
    setRefresh(!refresh);
  };

  return (
    <SafeAreaProvider>
      <StatusBar backgroundColor="#009387" barStyle="light-content" />
      <MenuProvider>
        <PaperProvider theme={MyTheme}>
          <AuthContext.Provider
            value={{
              user,
              setUser,
              deliverySheet,
              setDeliverySheet,
              update,
              setUpdate,
              updateStatus,
            }}>
            <Spinner
              visible={loading}
              textContent={'Please Wait ...'}
              textStyle={{color: '#fff'}}
              overlayColor={'rgba(0, 0, 0, 0.7)'}
            />
            <NavigationContainer theme={MyTheme}>
              {user ? (
                <Drawer.Navigator
                  initialRouteName="DeliverySheet"
                  drawerContent={props => (
                    <DrawerContent {...props} onSignOut={handleSignOut} />
                  )}>
                  <Drawer.Screen
                    name="DeliverySheet"
                    component={DeliverySheet}
                    options={{
                      headerTitle: 'Delivery Sheets',
                      headerTintColor: 'white',
                      headerStyle: {
                        backgroundColor: COLORS.greenColor,
                      },
                      headerTitleStyle: {
                        fontSize: 18,
                      },
                      headerLeftContainerStyle: {
                        marginTop: 2,
                        marginRight: -10,
                      },
                      headerRight: () => (
                        <Menu>
                          <MenuTrigger>
                            <Icon
                              name="ellipsis-vertical"
                              size={18}
                              backgroundColor={'#009387'}
                              color={'white'}
                              style={{
                                marginTop: 4,
                                marginLeft: 0,
                                marginRight: 15,
                              }}
                            />
                          </MenuTrigger>
                          <MenuOptions
                            optionsContainerStyle={{
                              padding: 10,
                              borderRadius: 5,
                              width: 150,
                              marginLeft: -12,
                            }}>
                            <MenuOption
                              onSelect={handleRefreshDeliverySheet}
                              style={{display: 'flex', flexDirection: 'row'}}>
                              <Icon
                                name="md-refresh-outline"
                                color="black"
                                size={15}
                                style={{marginTop: 2, marginRight: 5}}
                              />
                              <Text style={{color: 'black', fontWeight: '400'}}>
                                Refresh
                              </Text>
                            </MenuOption>

                            <MenuOption
                              onSelect={() => {
                                BackHandler.exitApp();
                              }}
                              style={{
                                display: 'flex',
                                flexDirection: 'row',
                                marginTop: 5,
                              }}>
                              <Icon
                                name="close"
                                color="black"
                                size={15}
                                style={{marginTop: 2, marginRight: 5}}
                              />
                              <Text style={{color: 'black', fontWeight: '400'}}>
                                Close App
                              </Text>
                            </MenuOption>
                          </MenuOptions>
                        </Menu>
                      ),
                    }}
                  />
                  <Drawer.Screen
                    name="AboutScreen"
                    component={AboutScreen}
                    options={{
                      headerTitle: 'About Us',
                      headerTintColor: 'white',
                      headerTitleStyle: {
                        fontSize: 18,
                      },
                      headerLeftContainerStyle: {
                        marginTop: 2,
                        marginRight: -10,
                      },
                      headerRight: () => (
                        <Menu>
                          <MenuTrigger>
                            <Icon
                              name="ellipsis-vertical"
                              size={18}
                              backgroundColor={'#009387'}
                              color={'white'}
                              style={{
                                marginTop: 4,
                                marginLeft: 0,
                                marginRight: 15,
                              }}
                            />
                          </MenuTrigger>
                          <MenuOptions
                            optionsContainerStyle={{
                              padding: 10,
                              borderRadius: 5,
                              width: 150,
                              marginLeft: -12,
                            }}>
                            <MenuOption
                              onSelect={() => {}}
                              style={{display: 'flex', flexDirection: 'row'}}>
                              <Icon
                                name="md-refresh-outline"
                                color="black"
                                size={15}
                                style={{marginTop: 2, marginRight: 5}}
                              />
                              <Text style={{color: 'black', fontWeight: '400'}}>
                                Refresh
                              </Text>
                            </MenuOption>

                            <MenuOption
                              onSelect={() => {
                                BackHandler.exitApp();
                              }}
                              style={{
                                display: 'flex',
                                flexDirection: 'row',
                                marginTop: 5,
                              }}>
                              <Icon
                                name="close"
                                color="black"
                                size={15}
                                style={{marginTop: 2, marginRight: 5}}
                              />
                              <Text style={{color: 'black', fontWeight: '400'}}>
                                Close App
                              </Text>
                            </MenuOption>
                          </MenuOptions>
                        </Menu>
                      ),
                    }}
                  />
                  <Drawer.Screen
                    name="ContactScreen"
                    component={ContactScreen}
                    options={{
                      headerTitle: 'Contact Us',
                      headerTintColor: 'white',
                      headerTitleStyle: {
                        fontSize: 18,
                      },
                      headerLeftContainerStyle: {
                        marginTop: 2,
                        marginRight: -10,
                      },
                      headerRight: () => (
                        <Menu>
                          <MenuTrigger>
                            <Icon
                              name="ellipsis-vertical"
                              size={18}
                              backgroundColor={'#009387'}
                              color={'white'}
                              style={{
                                marginTop: 4,
                                marginLeft: 0,
                                marginRight: 15,
                              }}
                            />
                          </MenuTrigger>
                          <MenuOptions
                            optionsContainerStyle={{
                              padding: 10,
                              borderRadius: 5,
                              width: 150,
                              marginLeft: -12,
                            }}>
                            <MenuOption
                              onSelect={() => {}}
                              style={{display: 'flex', flexDirection: 'row'}}>
                              <Icon
                                name="md-refresh-outline"
                                color="black"
                                size={15}
                                style={{marginTop: 2, marginRight: 5}}
                              />
                              <Text style={{color: 'black', fontWeight: '400'}}>
                                Refresh
                              </Text>
                            </MenuOption>

                            <MenuOption
                              onSelect={() => {
                                BackHandler.exitApp();
                              }}
                              style={{
                                display: 'flex',
                                flexDirection: 'row',
                                marginTop: 5,
                              }}>
                              <Icon
                                name="close"
                                color="black"
                                size={15}
                                style={{marginTop: 2, marginRight: 5}}
                              />
                              <Text style={{color: 'black', fontWeight: '400'}}>
                                Close App
                              </Text>
                            </MenuOption>
                          </MenuOptions>
                        </Menu>
                      ),
                    }}
                  />
                  <Drawer.Screen
                    name="MainTabScreen"
                    component={MainTabScreen}
                    options={{
                      headerShown: false,
                    }}
                  />
                </Drawer.Navigator>
              ) : (
                !loading && <RootStack />
              )}
            </NavigationContainer>
          </AuthContext.Provider>
        </PaperProvider>
      </MenuProvider>
    </SafeAreaProvider>
  );
};

export default App;
