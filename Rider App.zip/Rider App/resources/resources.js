export const COLORS = {
  persianGreenColor: '#009387',
  greenColor: '#009387',
  darkCerulean: '#009387',
};

export const API_KEYS = {
  googleMapsKey: 'AIzaSyAj0UaTz5D5pH2pstuSb9UEbiWSLVN6Pm0',
};
